﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        bool Opretion = false;


        static double PlusandMainus(double Value)
        {
            return Value * -1;
        }

        static double UpdateCalculetor(char Value, string DateValues)
        {

            if (DateValues == " ")
                return 0;

            if (Value == ' ')
                return 0;

            double Sum = 0;

            string[] Text;

            switch (Value)
            {


                case '+':

                    Text = DateValues.Split('+');
                    Sum += double.Parse(Text[0].ToString()) + double.Parse(Text[1].ToString());

                    break;

                case '-':

                    if (DateValues[0] == '-')
                    {

                        if (Value == '-')
                        {

                            Text = DateValues.Split('-', '+', '*', '/', '%');

                            if (double.Parse(Text[1].ToString()) < double.Parse(Text[2].ToString()))
                            {
                                Sum += PlusandMainus(-double.Parse(Text[2].ToString())) - double.Parse(Text[1].ToString());
                                break;
                            }
                            Sum += PlusandMainus(-double.Parse(Text[1].ToString())) - double.Parse(Text[2].ToString());
                            break;
                        }


                    }

                    Text = DateValues.Split('-');


                    Sum += double.Parse(Text[0].ToString()) - double.Parse(Text[1].ToString());


                    break;

                case 'x':

                    Text = DateValues.Split('x');
                    Sum += double.Parse(Text[0].ToString()) * double.Parse(Text[1].ToString());

                    break;

                case '÷':

                    Text = DateValues.Split('÷');
                    Sum += double.Parse(Text[0].ToString()) / double.Parse(Text[1].ToString());

                    break;

                case '%':

                    Text = DateValues.Split('%');
                    Sum += double.Parse(Text[0].ToString()) % double.Parse(Text[1].ToString());

                    break;

                case '²':

                    Text = DateValues.Split('X');
                    Sum += double.Parse(Text[0].ToString()) * double.Parse(Text[0].ToString());

                    break;


            }

            return Sum;
        }


        static char UpdateOpretions(string Values)
        {
            char Value = ' ';

            if (Values == "")
                return ' ';

            for (int i = 1; i <= Values.Length; i++)
            {

                switch (Values[i])
                {
                    case '+':
                        Value = Values[i];
                        return Value;

                    case '-':
                        Value = Values[i];
                        return Value;

                    case 'x':
                        Value = Values[i];
                        return Value;

                    case '÷':
                        Value = Values[i];
                        return Value;

                    case '%':
                        Value = Values[i];
                        return Value;

                }


            }

            return Value;
        }


        string AddTextButtonClick(System.Windows.Forms.Button btn)
        {
           textBox2.Text +=  btn.Tag as string;


            return textBox2.Text;        
        }


        private void ButtonClickNumbers(object sender, EventArgs e)
        {
            AddTextButtonClick((System.Windows.Forms.Button)sender);
        }


        private void btnPlusandNegtv_Click(object sender, EventArgs e)
        {

            textBox2.Text = PlusandMainus(int.Parse(textBox2.Text.ToString())).ToString();
        }

        private void btnAC_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox1.Text = 0.ToString();
            Opretion = false;
        }


        private void btnEcol_Click(object sender, EventArgs e)
        {
            if(Opretion == false)
                textBox1.Text = textBox2.Text;

            else
                textBox1.Text = UpdateCalculetor(UpdateOpretions(textBox2.Text), textBox2.Text).ToString();
        }

        private void btnX2_Click(object sender, EventArgs e)
        {
            if (Opretion == true)
            {
                textBox2.Text = 0.ToString();
            }
            else
            {
                textBox2.Text = (int.Parse(textBox2.Text) * int.Parse(textBox2.Text)).ToString();
                textBox1.Text = textBox2.Text;
            }
               

        }

        string Delete(string textBox2)
        {
            char Value = (textBox2[textBox2.Length - 1]);

            string ItemtextBox2 = "";

            for (int i = 0; i < textBox2.Length - 1; i++)
            {
                ItemtextBox2 += textBox2[i];
            }

            textBox2 = ItemtextBox2;

            return textBox2;

        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            textBox2.Text = Delete(textBox2.Text);

        }

        private void OpretionsClick(object sender, EventArgs e)
        {
            if (Opretion == true)
            {
                MessageBox.Show("Error!!", "Sorry Please Do Opretion One");
                return;
            }

            AddTextButtonClick((System.Windows.Forms.Button)sender);
            Opretion = true;
        }

    }
}

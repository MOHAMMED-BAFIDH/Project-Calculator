﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnNumber1 = new System.Windows.Forms.Button();
            this.btnNumber2 = new System.Windows.Forms.Button();
            this.btnNumber3 = new System.Windows.Forms.Button();
            this.btnNumber4 = new System.Windows.Forms.Button();
            this.btnNumber5 = new System.Windows.Forms.Button();
            this.btnNumber6 = new System.Windows.Forms.Button();
            this.btnNumber9 = new System.Windows.Forms.Button();
            this.btnNumber8 = new System.Windows.Forms.Button();
            this.btnNumber7 = new System.Windows.Forms.Button();
            this.btnPlusandNegtv = new System.Windows.Forms.Button();
            this.btnNumber0 = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEcol = new System.Windows.Forms.Button();
            this.btnposetev = new System.Windows.Forms.Button();
            this.btnmod = new System.Windows.Forms.Button();
            this.btnMulty = new System.Windows.Forms.Button();
            this.btnX2 = new System.Windows.Forms.Button();
            this.btnAC = new System.Windows.Forms.Button();
            this.btnNegetv = new System.Windows.Forms.Button();
            this.btndivid = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnNumber1
            // 
            this.btnNumber1.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber1.Location = new System.Drawing.Point(31, 245);
            this.btnNumber1.Name = "btnNumber1";
            this.btnNumber1.Size = new System.Drawing.Size(47, 37);
            this.btnNumber1.TabIndex = 0;
            this.btnNumber1.Tag = "1";
            this.btnNumber1.Text = "1";
            this.btnNumber1.UseVisualStyleBackColor = false;
            this.btnNumber1.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber2
            // 
            this.btnNumber2.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber2.Location = new System.Drawing.Point(119, 245);
            this.btnNumber2.Name = "btnNumber2";
            this.btnNumber2.Size = new System.Drawing.Size(47, 37);
            this.btnNumber2.TabIndex = 1;
            this.btnNumber2.Tag = "2";
            this.btnNumber2.Text = "2";
            this.btnNumber2.UseVisualStyleBackColor = false;
            this.btnNumber2.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber3
            // 
            this.btnNumber3.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber3.Location = new System.Drawing.Point(207, 245);
            this.btnNumber3.Name = "btnNumber3";
            this.btnNumber3.Size = new System.Drawing.Size(47, 37);
            this.btnNumber3.TabIndex = 2;
            this.btnNumber3.Tag = "3";
            this.btnNumber3.Text = "3";
            this.btnNumber3.UseVisualStyleBackColor = false;
            this.btnNumber3.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber4
            // 
            this.btnNumber4.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber4.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber4.Location = new System.Drawing.Point(31, 310);
            this.btnNumber4.Name = "btnNumber4";
            this.btnNumber4.Size = new System.Drawing.Size(47, 37);
            this.btnNumber4.TabIndex = 3;
            this.btnNumber4.Tag = "4";
            this.btnNumber4.Text = "4";
            this.btnNumber4.UseVisualStyleBackColor = false;
            this.btnNumber4.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber5
            // 
            this.btnNumber5.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber5.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber5.Location = new System.Drawing.Point(119, 310);
            this.btnNumber5.Name = "btnNumber5";
            this.btnNumber5.Size = new System.Drawing.Size(47, 37);
            this.btnNumber5.TabIndex = 4;
            this.btnNumber5.Tag = "5";
            this.btnNumber5.Text = "5";
            this.btnNumber5.UseVisualStyleBackColor = false;
            this.btnNumber5.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber6
            // 
            this.btnNumber6.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber6.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber6.Location = new System.Drawing.Point(207, 310);
            this.btnNumber6.Name = "btnNumber6";
            this.btnNumber6.Size = new System.Drawing.Size(47, 37);
            this.btnNumber6.TabIndex = 5;
            this.btnNumber6.Tag = "6";
            this.btnNumber6.Text = "6";
            this.btnNumber6.UseVisualStyleBackColor = false;
            this.btnNumber6.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber9
            // 
            this.btnNumber9.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber9.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber9.Location = new System.Drawing.Point(207, 375);
            this.btnNumber9.Name = "btnNumber9";
            this.btnNumber9.Size = new System.Drawing.Size(47, 37);
            this.btnNumber9.TabIndex = 8;
            this.btnNumber9.Tag = "9";
            this.btnNumber9.Text = "9";
            this.btnNumber9.UseVisualStyleBackColor = false;
            this.btnNumber9.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber8
            // 
            this.btnNumber8.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber8.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber8.Location = new System.Drawing.Point(119, 375);
            this.btnNumber8.Name = "btnNumber8";
            this.btnNumber8.Size = new System.Drawing.Size(47, 37);
            this.btnNumber8.TabIndex = 7;
            this.btnNumber8.Tag = "8";
            this.btnNumber8.Text = "8";
            this.btnNumber8.UseVisualStyleBackColor = false;
            this.btnNumber8.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnNumber7
            // 
            this.btnNumber7.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber7.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber7.Location = new System.Drawing.Point(31, 375);
            this.btnNumber7.Name = "btnNumber7";
            this.btnNumber7.Size = new System.Drawing.Size(47, 37);
            this.btnNumber7.TabIndex = 6;
            this.btnNumber7.Tag = "7";
            this.btnNumber7.Text = "7";
            this.btnNumber7.UseVisualStyleBackColor = false;
            this.btnNumber7.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnPlusandNegtv
            // 
            this.btnPlusandNegtv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnPlusandNegtv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPlusandNegtv.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPlusandNegtv.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlusandNegtv.Location = new System.Drawing.Point(119, 442);
            this.btnPlusandNegtv.Name = "btnPlusandNegtv";
            this.btnPlusandNegtv.Size = new System.Drawing.Size(47, 37);
            this.btnPlusandNegtv.TabIndex = 10;
            this.btnPlusandNegtv.Tag = "!";
            this.btnPlusandNegtv.Text = "+/-";
            this.btnPlusandNegtv.UseVisualStyleBackColor = false;
            this.btnPlusandNegtv.Click += new System.EventHandler(this.btnPlusandNegtv_Click);
            // 
            // btnNumber0
            // 
            this.btnNumber0.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnNumber0.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNumber0.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNumber0.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumber0.Location = new System.Drawing.Point(31, 442);
            this.btnNumber0.Name = "btnNumber0";
            this.btnNumber0.Size = new System.Drawing.Size(47, 37);
            this.btnNumber0.TabIndex = 9;
            this.btnNumber0.Tag = "0";
            this.btnNumber0.Text = "0";
            this.btnNumber0.UseVisualStyleBackColor = false;
            this.btnNumber0.Click += new System.EventHandler(this.ButtonClickNumbers);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.SystemColors.GrayText;
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDelete.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(207, 442);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(47, 37);
            this.btnDelete.TabIndex = 12;
            this.btnDelete.Tag = "";
            this.btnDelete.Text = "Del";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click_1);
            // 
            // btnEcol
            // 
            this.btnEcol.BackColor = System.Drawing.Color.Gold;
            this.btnEcol.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEcol.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnEcol.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEcol.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEcol.Location = new System.Drawing.Point(295, 442);
            this.btnEcol.Name = "btnEcol";
            this.btnEcol.Size = new System.Drawing.Size(47, 37);
            this.btnEcol.TabIndex = 13;
            this.btnEcol.Tag = "=";
            this.btnEcol.Text = "=";
            this.btnEcol.UseVisualStyleBackColor = false;
            this.btnEcol.Click += new System.EventHandler(this.btnEcol_Click);
            // 
            // btnposetev
            // 
            this.btnposetev.BackColor = System.Drawing.Color.Gold;
            this.btnposetev.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnposetev.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnposetev.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnposetev.Location = new System.Drawing.Point(295, 375);
            this.btnposetev.Name = "btnposetev";
            this.btnposetev.Size = new System.Drawing.Size(47, 37);
            this.btnposetev.TabIndex = 14;
            this.btnposetev.Tag = "+";
            this.btnposetev.Text = "+";
            this.btnposetev.UseVisualStyleBackColor = false;
            this.btnposetev.Click += new System.EventHandler(this.OpretionsClick);
            // 
            // btnmod
            // 
            this.btnmod.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnmod.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnmod.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmod.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmod.Location = new System.Drawing.Point(207, 180);
            this.btnmod.Name = "btnmod";
            this.btnmod.Size = new System.Drawing.Size(47, 37);
            this.btnmod.TabIndex = 15;
            this.btnmod.Tag = "%";
            this.btnmod.Text = "%";
            this.btnmod.UseVisualStyleBackColor = false;
            this.btnmod.Click += new System.EventHandler(this.OpretionsClick);
            // 
            // btnMulty
            // 
            this.btnMulty.BackColor = System.Drawing.Color.Gold;
            this.btnMulty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnMulty.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMulty.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMulty.Location = new System.Drawing.Point(295, 245);
            this.btnMulty.Name = "btnMulty";
            this.btnMulty.Size = new System.Drawing.Size(47, 37);
            this.btnMulty.TabIndex = 16;
            this.btnMulty.Tag = "x";
            this.btnMulty.Text = "x";
            this.btnMulty.UseVisualStyleBackColor = false;
            this.btnMulty.Click += new System.EventHandler(this.OpretionsClick);
            // 
            // btnX2
            // 
            this.btnX2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnX2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnX2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnX2.Font = new System.Drawing.Font("Tahoma", 18F);
            this.btnX2.Location = new System.Drawing.Point(122, 180);
            this.btnX2.Name = "btnX2";
            this.btnX2.Size = new System.Drawing.Size(47, 37);
            this.btnX2.TabIndex = 17;
            this.btnX2.Tag = "²";
            this.btnX2.Text = "x²";
            this.btnX2.UseVisualStyleBackColor = false;
            this.btnX2.Click += new System.EventHandler(this.btnX2_Click);
            // 
            // btnAC
            // 
            this.btnAC.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.btnAC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAC.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAC.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAC.Location = new System.Drawing.Point(31, 180);
            this.btnAC.Name = "btnAC";
            this.btnAC.Size = new System.Drawing.Size(47, 37);
            this.btnAC.TabIndex = 18;
            this.btnAC.Tag = "AC";
            this.btnAC.Text = "AC";
            this.btnAC.UseVisualStyleBackColor = false;
            this.btnAC.Click += new System.EventHandler(this.btnAC_Click);
            // 
            // btnNegetv
            // 
            this.btnNegetv.BackColor = System.Drawing.Color.Gold;
            this.btnNegetv.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNegetv.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNegetv.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNegetv.Location = new System.Drawing.Point(295, 310);
            this.btnNegetv.Name = "btnNegetv";
            this.btnNegetv.Size = new System.Drawing.Size(47, 37);
            this.btnNegetv.TabIndex = 19;
            this.btnNegetv.Tag = "-";
            this.btnNegetv.Text = "-";
            this.btnNegetv.UseVisualStyleBackColor = false;
            this.btnNegetv.Click += new System.EventHandler(this.OpretionsClick);
            // 
            // btndivid
            // 
            this.btndivid.BackColor = System.Drawing.Color.Gold;
            this.btndivid.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndivid.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btndivid.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndivid.Location = new System.Drawing.Point(295, 180);
            this.btndivid.Name = "btndivid";
            this.btndivid.Size = new System.Drawing.Size(47, 37);
            this.btndivid.TabIndex = 20;
            this.btndivid.Tag = "÷";
            this.btndivid.Text = "÷";
            this.btndivid.UseVisualStyleBackColor = false;
            this.btndivid.Click += new System.EventHandler(this.OpretionsClick);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("Tahoma", 18F);
            this.textBox1.Location = new System.Drawing.Point(31, 139);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(348, 36);
            this.textBox1.TabIndex = 21;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.textBox2.Enabled = false;
            this.textBox2.Font = new System.Drawing.Font("Tahoma", 14F);
            this.textBox2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.textBox2.Location = new System.Drawing.Point(31, 97);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(348, 30);
            this.textBox2.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(391, 511);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btndivid);
            this.Controls.Add(this.btnNegetv);
            this.Controls.Add(this.btnAC);
            this.Controls.Add(this.btnX2);
            this.Controls.Add(this.btnMulty);
            this.Controls.Add(this.btnmod);
            this.Controls.Add(this.btnposetev);
            this.Controls.Add(this.btnEcol);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnPlusandNegtv);
            this.Controls.Add(this.btnNumber0);
            this.Controls.Add(this.btnNumber9);
            this.Controls.Add(this.btnNumber8);
            this.Controls.Add(this.btnNumber7);
            this.Controls.Add(this.btnNumber6);
            this.Controls.Add(this.btnNumber5);
            this.Controls.Add(this.btnNumber4);
            this.Controls.Add(this.btnNumber3);
            this.Controls.Add(this.btnNumber2);
            this.Controls.Add(this.btnNumber1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnNumber1;
        private System.Windows.Forms.Button btnNumber2;
        private System.Windows.Forms.Button btnNumber3;
        private System.Windows.Forms.Button btnNumber4;
        private System.Windows.Forms.Button btnNumber5;
        private System.Windows.Forms.Button btnNumber6;
        private System.Windows.Forms.Button btnNumber9;
        private System.Windows.Forms.Button btnNumber8;
        private System.Windows.Forms.Button btnNumber7;
        private System.Windows.Forms.Button btnPlusandNegtv;
        private System.Windows.Forms.Button btnNumber0;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEcol;
        private System.Windows.Forms.Button btnposetev;
        private System.Windows.Forms.Button btnmod;
        private System.Windows.Forms.Button btnMulty;
        private System.Windows.Forms.Button btnX2;
        private System.Windows.Forms.Button btnAC;
        private System.Windows.Forms.Button btnNegetv;
        private System.Windows.Forms.Button btndivid;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}

